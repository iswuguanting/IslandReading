import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '@/views/HomeView.vue'
import ExploreView from '@/views/ExploreView.vue'
import UserVIew from '@/views/UserVIew.vue'
import DetailsView from '@/views/Home/DetailsView.vue'


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/home',
      name: 'home',
      component: HomeView,
      meta: {
        show: true,
        keepAlive:true
      }
    },
    
    {
      path: '/explore',
      name: 'explore',
      component: ExploreView,
      meta: {
        show: true,
        keepAlive:true
      }
    },
    {
      path: '/user',
      name: 'user',
      component: UserVIew,
      meta: {
        show: true,
        keepAlive:true
      }
    },
    {
      path: '/details',
      name: 'details',
      component: DetailsView,
      meta: {
        show: false,
        keepAlive:false
      }
    },
  ]
})

export default router
