<script setup lang="ts">
import { defineComponent,ref} from "vue";
import { RouterLink, RouterView } from "vue-router";
import type { LessonsType, peopleType } from "@/TypeValidation";

// 接收父组件传递的数据
// const props = defineProps({
//     isShowTo: {
//     type: Boolean,
//   }
// });

const props = defineProps<{
    isShowTo: boolean,
    article:string | undefined,
    peopl:peopleType[],
}>();
const emit = defineEmits(['gomyfarther'])
const gomyfarther = () => {
    emit('gomyfarther', true);
}

const isShowTo = ref(props.isShowTo);
console.log(isShowTo.value,222222);


</script>

<template>
    <!-- animate__fadeInUp -->
    <main class="contengs " @click="gomyfarther">探索</main>
</template>

<style lang="scss" scoped>
.contengs {
    width: 100vw;
    height: 100vh;
    background: linear-gradient(180deg, #d7dddd 0%, #bdbed0 100%);

}
</style>