export function getTimestamp(time: string | number | Date) {
    let date = new Date(time);
    let y = date.getFullYear();
    let m = date.getMonth() + 1;
    let d = date.getDate();

    return {
        no_time: `${y}-${m}-${d}`,
        time: `${y}-${m}-${d} ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`,
        times: `${y}${m}${d}`,
        timestamp: date.getTime(),
        date: `${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`
    };
}

// 星期几  根据时间年月日
export function getWeek(timestamp: number | string) {
    let date = timestamp;

    let y = date.toString().substring(0, 4);
    let m = date.toString().substring(4, 6);
    let d = date.toString().substring(6);
    let week = new Date(`${y}-${m}-${d}`).getDay();
    switch (week) {
        case 0:
            return "周日";
        case 1:
            return "周一";
        case 2:
            return "周二";
        case 3:
            return "周三";
        case 4:
            return "周四";
        case 5:
            return "周五";
        case 6:
            return "周六";
        default:
            return "";
    }
}

// 将数字转为中文
export function numandchiniese(num: number | string) {
    let numStr = num.toString();

    switch (numStr) {
        case '1':
            return "一";
        case '2':
            return "二";
        case '3':
            return "三";
        case '4':
            return "四";
        case '5':
            return "五";
        case '6':
            return "六";
        case '7':
            return "七";
        case '8':
            return "八";
        case '9':
            return "九";
        case '0':
            return "零";
        default:
            return "";

    }

}