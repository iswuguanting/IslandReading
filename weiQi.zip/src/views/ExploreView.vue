<script setup lang="ts">
import { defineComponent, ref } from "vue";
import { RouterLink, RouterView } from "vue-router";

</script>

<template>
    <div class="bosonf">
        <main class="contengs">
            <div>
                
            </div>
        </main>
        <footer class="foo">
            <div>
                <van-icon class="replay" name="replay" />
            </div>
            <div>
                <van-icon class="clear" name="cross" />
            </div>
            <div>
                <van-icon class="linke" name="like" />
            </div>
        </footer>
    </div>
</template>

<style lang="scss" scoped>
.bosonf {
    width: 100vw;
    height: 100vh;
    background: linear-gradient(180deg, #d7dddd 0%, #bdbed0 100%);

    .contengs {
        width: 100%;
        height: 80%;
        background-color: aqua;
    }

    .foo {
        width: 100%;
        height: 10%;
        // background-color: red;
        display: flex;
        padding: 0 50rem;

        &>div {
            // width: 100%;
            width: 33.333%;
            height: 100%;
            // background-color: aqua;
            position: relative;
            

            .replay{
                width: 50rem;
                height: 50rem;
                position: absolute;
                background-color: white;
                border-radius: 999rem;
                font-size: 30rem;
                line-height: 50rem;
                text-align: center;
                color: #bbbdcb;
                left: 0;
                right: 0;
                top: 0;
                bottom: 0;
                margin: auto;
                box-shadow: 0 0 10rem 0 rgba(0, 0, 0, 0.2);
            }

            .clear{
                width: 60rem;
                height: 60rem;
                position: absolute;
                background-color: white;
                border-radius: 999rem;
                font-size: 30rem;
                line-height: 60rem;
                text-align: center;
                color: #bbbdcb;
                left: 0;
                right: 0;
                top: 0;
                bottom: 0;
                margin: auto;
                box-shadow: 0 0 10rem 0 rgba(0, 0, 0, 0.2);
            }

            .linke {
                width: 50rem;
                height: 50rem;
                position: absolute;
                background-color: white;
                border-radius: 999rem;
                font-size: 30rem;
                line-height: 50rem;
                text-align: center;
                color: #bbbdcb;
                left: 0;
                right: 0;
                top: 0;
                bottom: 0;
                margin: auto;
                box-shadow: 0 0 10rem 0 rgba(0, 0, 0, 0.2);
            }
        }
    }
}
</style>