// 主页轮播图的数据类型判断
export interface LessonsType {
    article: string
    id: string
    title: string
    author:{
        id: number | string
        name: string
    }
    date_by_day: number | string
    created_at:number | string
    updated_at:number | string
    provenance: string
    comment_count: number
    favourite_count: number
}

interface articleType {
    0: string
}

export interface peopleType {
    content:string | number
    content_tr_zh_hant?:string
    created_at:number
    id:string
    lesson_id:string
    user:{
        avatar:string
        id:string
        nickname:string
    }
}
